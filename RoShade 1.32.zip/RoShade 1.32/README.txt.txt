Roblox Shaders Ultimate v2.0

Transforme seus jogos Roblox com gráficos realistas!

- Iluminação avançada  
- Sombras dinâmicas  
- Reflexos em tempo real  

Para instalar:  
Copie os arquivos para a pasta Roblox/Shaders e reinicie o jogo.  

Divirta-se!
